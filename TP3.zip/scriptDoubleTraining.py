import transformData
import networkL2
import pre
import numpy as np
import random

print("TEST CASE: DOUBLE TRAINING (file out: outDoubleTraining)\n")
print("NETWORK: [784,90,10]\n")
print("20 epochs, 50 mini batch size, 3.0 learning rate\n\n")
## create net
net = networkL2.Network([784, 90, 10])
## train net
print("FIRST TRAINING\n\n")
net.SGD(transformData.trainD, 20, 50, 3.0, 5.0, test_data=transformData.validationD)
## get new train and validation sets
print("\n\n")
## load train.csv
trainD = pre.csv_a_lista('train.csv')

def pepu(f):
    return np.array([f],dtype='float32')

trainD = map(lambda (x,y): (map(pepu,x),y), trainD)

trainD = map(lambda (u,v): (np.array(u),v), trainD)

random.shuffle(trainD)
# 29400 : 70% train.csv
validationD = trainD[29400:]
trainD = trainD[:29400]

def trans(n):
    res = np.zeros([10,1])
    res[n] = np.float(1)
    return res

trainD = map(lambda (x, y): (x, trans(y)), trainD)

## train net again
print("SECOND TRAINING\n\n")
net.SGD(trainD, 20, 50, 3.0, 5.0, test_data=validationD)
print("\n\n")


## get prediction
predicted = net.predict(transformData.testD)
predicted = [np.argmax(x) for x in predicted]
with open('outDoubleTrainingL2','w') as f_predicted:
	f_predicted.write('ImageId,Label\n')
	for i in range(len(predicted)):
		f_predicted.write('%s,%s\n'  % (str(i+1),str(predicted[i])))
