import numpy as np
import pre
#import network
import random


## load train.csv
trainD = pre.csv_a_lista('train.csv')

def pepu(f):
    return np.array([f],dtype='float32')

trainD = map(lambda (x,y): (map(pepu,x),y), trainD)

trainD = map(lambda (u,v): (np.array(u),v), trainD)

random.shuffle(trainD)
# 29400 : 70% train.csv
validationD = trainD[29400:]
trainD = trainD[:29400]

def trans(n):
    res = np.zeros([10,1])
    res[n] = np.float(1)
    return res

trainD = map(lambda (x, y): (x, trans(y)), trainD)

# load test.csv
def get_test_data(filename):
    with open(filename, "r") as fTest_data:
        test_data = fTest_data.read().splitlines()[1:] #read and skip first line (pixel1,pixel2...)
    test_data_formated = map(lambda x: [np.array(y,dtype='float32') for y in x.split(',')], test_data)
    test_data_formated = map(lambda x: np.array(x),test_data_formated)

    return test_data_formated

testD = map(lambda x: pre.convertir_aplicar_filtro(x), get_test_data('test.csv'))
testD = map(lambda x: np.array(map(pepu,x)), testD)


## create net
#net = networkConCrossEntropy.Network([784, 30, 10])
#net = networkL2.Network([784, 90, 10])
## train net
#net.SGD(transformData2.trainD, 10, 30, 3.0, test_data=transformData2.validationD)
#net.SGD(transformData.trainD, 20, 50, 3.0, 5.0, test_data=transformData.validationD)
## get prediction
#predicted = net.predict(testD)
