import numpy as np
import preRot
import networkW
import random


## load train.csv
trainD = preRot.csv_a_lista('train.csv',15)

def pepu(f):
    return np.array([f],dtype='float32')

#trainD = map(lambda (x,y): (map(pepu,x),y), trainD)

trainD = map(lambda (u,v): ((np.array(u)).flatten(),v), trainD)
trainD = map(lambda (x,y): (map(pepu,x),y), trainD)
trainD = map(lambda (x,y): (np.array(x), y), trainD)

random.shuffle(trainD)
# El set con los numeros rotados tiene 84000 numeros
# El 70% de 84000 es 58800
validationD = trainD[58800:]
trainD = trainD[:58800]

#trainD = map(lambda (x,y): (np.array(x),y), trainD)
#validationD = map(lambda (x,y): (map(pepu,x),y), validationD)

def trans(n):
    res = np.zeros([10,1])
    res[n] = np.float(1)
    return res

trainD = map(lambda (x, y): (x, trans(y)), trainD)

# load test.csv
def get_test_data(filename):
    with open(filename, "r") as fTest_data:
        test_data = fTest_data.read().splitlines()[1:] #read and skip first line (pixel1,pixel2...)
    test_data_formated = map(lambda x: [np.array(y,dtype='float32') for y in x.split(',')], test_data)
    test_data_formated = map(lambda x: np.array(x),test_data_formated)

    return test_data_formated

testD = map(lambda x: preRot.convertir_aplicar_filtro(x), get_test_data('test.csv'))
testD = map(lambda x: np.array(map(pepu,x)), testD)


## create net
#net = network.Network([784, 30, 10])
## train net
#net.SGD(trainD, 10, 30, 3.0, test_data=validationD)
## get prediction
#predicted = net.predict(testD)
