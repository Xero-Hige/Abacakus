import numpy as np
import transformDataRot2
import networkW

# ver en "resultadospredicciones1" (y en "resultadospredicciones")
for x in range(40,301,10):
	## create net with 1 hidden layer with x neurons
	net = networkW.Network([784, x, 10])
	print("TEST WITH %d NEURONS IN 1 HIDDEN LAYER\n" % x)
	## train net with 10 epochs and 50 mini batch size
	net.SGD(transformDataRot2.trainD, 10, 50, 2.6, 7.0, test_data=transformDataRot2.validationD)
	print("Correct evaluation of the train data (total: 29400): ")
	net.evaluate(transformDataRot2.trainD)
	print("\n")

# ver salida en "resultadospredicciones2"
#for y in range(100,601,100):
#	for x in [30,60,90]:
#		net = network.Network([784, y, 30, 10])
#		print("TEST WITH %d NEURONS IN THE 1ST HIDDEN LAYER AND %d IN 2ND\n" % (y,x))
#		net.SGD(transformData.trainD, 10,30,3.0, test_data=transformData.validationD)

#for x in range(10, 100, 10):
#	net = network.Network([784,90,10])
#	print("TEST WITH %d MINI BATCH SIZE\n" % x)
#	net.SGD(transformData.trainD, 10, x, 3.0, test_data=transformData.validationD)

#Para testear lr
#~ for x in np.arange(1.00, 10.0, 1.0):
	#~ net = networkL2.Network([784,90,10])
	#~ print("TEST WITH %d LEARNING RATE\n" % x)
	#~ net.SGD(transformData.trainD, 10, 50, x, 0.0, test_data=transformData.validationD)

#~ for y in range(10, 101,10):
	#~ net = networkW.Network([784,90,10])
	#~ print("TEST WITH %d EPOCHS\n" % y)
	#~ net.SGD(transformData.trainD, y, 50, 2.6, 7.0, test_data=transformData.validationD)
