from scipy import ndimage
import math
from csv import*
import numpy as np
import matplotlib.pyplot as plt


def convertir_aplicar_filtro(lista):
	for x in range(len(lista)):
  		lista[x]=int(lista[x])
	lista=np.array(lista).astype(np.float)
	#lista=ndimage.gaussian_filter(lista, 2)
	#lista=ndimage.median_filter(lista, 3)
	lista=ndimage.binary_erosion(lista).astype(lista.dtype)
	#lista=ndimage.binary_dilation(lista).astype(lista.dtype)
	return lista
 
def imprimir(lista, label):
  for x in range(len(lista)):
  	lista[x]=int(lista[x])
  m=np.array(lista).reshape(28,28)
  plt.matshow(m, cmap=plt.cm.gray)
  plt.show()
  print(label)


def csv_a_lista(nombre_archivo):
	i_inicial=0
	set_datos={}
	archivo = open(nombre_archivo)
	archivo.readline()
	train_lista=[]
	for linea in archivo :
		linea = linea.rstrip(";\r\n")
		linea_pixeles= linea.split(",")
		n=linea_pixeles.pop(i_inicial)
		train_lista.append((convertir_aplicar_filtro(linea_pixeles),int(n)))
	archivo.close() 
	return train_lista

#numeros = csv_a_lista("train.csv")

#imprimir(numeros[0][0],numeros[0][1])
